﻿using Xunit;

namespace $safeprojectname$
{
    public class Tests
    {
        [Fact]
        public void Method_When_Should()
        {
            // arrange

            // act

            // assert

        }
    }
}
