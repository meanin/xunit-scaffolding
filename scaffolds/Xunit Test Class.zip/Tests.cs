﻿using Xunit;

namespace $rootnamespace$
{
    public class $safeitemname$
    {
        [Fact]
        public void Method_When_Should()
        {
            // arrange

            // act

            // assert

        }
    }
}
